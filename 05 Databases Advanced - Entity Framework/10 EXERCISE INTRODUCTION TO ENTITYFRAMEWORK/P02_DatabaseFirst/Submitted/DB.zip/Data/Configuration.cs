﻿namespace P02_DatabaseFirst.Data
{
    class Configuration
    {
        public const string ConfigurationString = @"Server=.\SQLEXPRESS;Database=SoftUni;Integrated Security=True";
    }
}
