﻿public class Kittens : Cat
{
    private const string sound = "Meow";
    private const string gender = "Female";

    public Kittens(string name, int age)
        : base(name, age, gender, sound)
    {

    }
}