﻿namespace Problem_3.Shopping_Spree
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Reflection;

    public class StartUp
    {
        static void Main(string[] args)
        {
            try
            {
                List<Person> people = new List<Person>();

                ReadPeople(people);

                List<Product> products = new List<Product>();

                ReadProducts(products);

                BuyProducts(people, products);

                PrintPeopleAndBoughtProducts(people);

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void BuyProducts(List<Person> people, List<Product> products)
        {
            string dataInput;
            while ((dataInput = Console.ReadLine()) != "END")
            {
                string[] cmdArg = dataInput.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries).ToArray();
                if (cmdArg.Length == 2)
                {
                    string personName = cmdArg[0];
                    string productName = cmdArg[1];

                    Person client = people.First(x => x.Name == personName);

                    Product product = products.First(x => x.Name == productName);

                    if (client != null || product != null)
                    {
                        client.BuyProduct(product);
                    }
                }
                else
                {
                    throw new ArgumentException("Name cannot be empty");
                }

            }
        }

        private static void PrintPeopleAndBoughtProducts(List<Person> people)
        {
            foreach (var person in people)
            {
                string result;
                if (person.Products.Count == 0)
                {
                    result = "Nothing bought";
                }
                else
                {
                    var productNames = person.Products.Select(p => p.Name).ToArray();

                    result = string.Join(", ", productNames);
                }

                Console.WriteLine($"{person.Name} - {result}");
            }
        }

        private static void ReadProducts(List<Product> products)
        {
            string[] inputProducts = Console.ReadLine().Split(new char[] { ';' }, StringSplitOptions.RemoveEmptyEntries).ToArray();

            foreach (var input in inputProducts)
            {
                string[] els = input.Split('=');
                string productName = els[0].Trim();
                decimal productPrice = decimal.Parse(els[1].Trim());
                products.Add(new Product(productName, productPrice));
            }
        }

        private static void ReadPeople(List<Person> people)
        {
            string[] inputPeople = Console.ReadLine().Split(new char[] { ';' }, StringSplitOptions.RemoveEmptyEntries).ToArray();

            foreach (var input in inputPeople)
            {
                string[] els = input.Split('=');
                string personName = els[0].Trim();
                decimal personMoney = decimal.Parse(els[1].Trim());
                people.Add(new Person(personName, personMoney));
            }
        }
    }
}
