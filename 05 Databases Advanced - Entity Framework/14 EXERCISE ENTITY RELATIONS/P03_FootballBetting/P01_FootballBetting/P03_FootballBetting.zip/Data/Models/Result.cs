﻿namespace P03_FootballBetting.Data.Models
{
    public enum Result
    {
        Draw=0, HomeTeamWin=1, AwayTeamWin=2
    }
}
