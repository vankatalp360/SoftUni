﻿namespace P01_StudentSystem.Data.Configurations
{
    class Configuration
    {
        public const string ConnectionString = @"Server=.\SQLEXPRESS;Database=StudentSystemContext;Integrated Security=true";
    }
}