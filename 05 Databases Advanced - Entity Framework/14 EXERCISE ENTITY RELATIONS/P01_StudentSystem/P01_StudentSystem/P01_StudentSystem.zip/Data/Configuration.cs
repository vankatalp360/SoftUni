﻿namespace P01_StudentSystem.Data
{
    class Configuration
    {
        public const string ConnectionString = @"Server=.\SQLEXPRESS;Database=StudentSystemContext;Integrated Security=true";
    }
}
