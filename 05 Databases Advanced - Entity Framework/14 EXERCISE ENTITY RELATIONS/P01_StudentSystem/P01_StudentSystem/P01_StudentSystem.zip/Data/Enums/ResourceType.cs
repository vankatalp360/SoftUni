﻿namespace P01_StudentSystem.Data.Enums
{
    public enum ResourceType
    {
        Video,
        Presentation,
        Document,
        Other
    }
}