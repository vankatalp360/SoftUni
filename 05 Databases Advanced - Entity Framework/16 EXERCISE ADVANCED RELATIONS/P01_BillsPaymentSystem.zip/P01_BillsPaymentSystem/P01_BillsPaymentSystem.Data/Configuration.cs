﻿namespace P01_BillsPaymentMethodsystem.Data
{
    class Configuration
    {
        public const string ConnectionString = @"Server=.\SQLEXPRESS;Database=BillsPaymentSystemContext;Integrated Security=true";
    }
}
