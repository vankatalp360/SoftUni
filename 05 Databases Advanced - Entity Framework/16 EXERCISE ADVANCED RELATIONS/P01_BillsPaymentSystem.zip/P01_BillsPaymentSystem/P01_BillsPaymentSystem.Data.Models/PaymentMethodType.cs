﻿namespace P01_BillsPaymentMethodsystem.Data.Models
{
    public enum PaymentMethodType
    {
        BankAccount,
        CreditCard
    }
}
