﻿namespace P01_HospitalDatabase.Data
{
    class Configuration
    {
        public const string ConnectionString = @"Server=.\SQLEXPRESS;Database=HospitalContext;Integrated Security=true";
    }
}
