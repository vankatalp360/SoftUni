﻿namespace P03_SalesDatabase.Data
{
    class Configuration
    {
        public const string ConnectionString = @"Server=.\SQLEXPRESS;Database=SalesDatabase;Integrated Security=true";
    }
}
