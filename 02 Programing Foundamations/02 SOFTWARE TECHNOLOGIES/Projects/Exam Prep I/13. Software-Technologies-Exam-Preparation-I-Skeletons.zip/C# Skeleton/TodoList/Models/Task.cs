﻿using System.Web.Mvc;

namespace TodoList.Models
{
    public class Task
    {
        //TODO: Implement me...
    }
}