package todolist.bindingModel;

public class TaskBindingModel {
	//TODO:Implement me...
}
